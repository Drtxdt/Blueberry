Blueberry beta fixture
